#define _CRT_SECURE_NO_WARNINGS

#include "stdio.h"

int data[8192] = {0};
int contextStack[8192] = {0}, contextStackIndex = 0;
int opStack[8192] = {0}, opStackIndex = 0, opTemp = 0;
int lastBindDataIndex = 0;

int main() {
    contextStackIndex = 0;
    opStackIndex = 0;
    opTemp = 0;
    lastBindDataIndex = 0;

    //";"

    //"4"
    opStack[++opStackIndex] = opTemp = 0x00000004;

    //"get"
    (void)scanf_s("%d", &opTemp);
    data[opStack[opStackIndex]] = opTemp, opStackIndex = 0;

    //null statement (non-context)

    //"8"
    opStack[++opStackIndex] = opTemp = 0x00000008;

    //"1"
    opStack[++opStackIndex] = opTemp = 0x00000001;

    //"<-"
    lastBindDataIndex = opStack[opStackIndex - 1];
    data[lastBindDataIndex] = opTemp = opStack[opStackIndex], opStackIndex = 0;

    //null statement (non-context)

    //"for"

    //"12"
    opStack[++opStackIndex] = opTemp = 0x0000000C;

    //"0"
    opStack[++opStackIndex] = opTemp = 0x00000000;

    //"<-"
    lastBindDataIndex = opStack[opStackIndex - 1];
    data[lastBindDataIndex] = opTemp = opStack[opStackIndex], opStackIndex = 0;

    //null statement (non-context)

    //"to" (after "for")
    --data[lastBindDataIndex];
    contextStack[++contextStackIndex] = lastBindDataIndex;
    LABEL__AFTER_TO_00007FF6605854E8:

    //"32767"
    opStack[++opStackIndex] = opTemp = 0x00007FFF;

    //null statement (non-context)

    //"do" (after "to" after "for")
    if (opStack[contextStack[contextStackIndex]] >= opTemp) goto LABEL__EXIT_FOR_00007FF660583BF8;
    ++opStack[contextStack[contextStackIndex]];

    //"if"

    //"_VAL"
    opStack[++opStackIndex] = opTemp = data[0x00000004];

    //"0"
    opStack[++opStackIndex] = opTemp = 0x00000000;

    //"noteq"
    opTemp = opStack[opStackIndex - 1] = opStack[opStackIndex - 1] != opStack[opStackIndex--];

    //after cond expresion (after "if")
    if (opTemp == 0) goto LABEL__AFTER_THEN_00007FF660587A50;

    //";" (after "then"-part of if-operator)
    opTemp = 1;
    LABEL__AFTER_THEN_00007FF660587A50:

    //"else"
    if (opTemp != 0) goto LABEL__AFTER_ELSE_00007FF6605886C8;

    //"goto" previous ident "_END"(as label)
    goto LABEL__0000024B1459FA48;

    //null statement (non-context)

    //";" (after "else")
    LABEL__AFTER_ELSE_00007FF6605886C8:

    //"8"
    opStack[++opStackIndex] = opTemp = 0x00000008;

    //"_RES"
    opStack[++opStackIndex] = opTemp = data[0x00000008];

    //"_VAL"
    opStack[++opStackIndex] = opTemp = data[0x00000004];

    //"*"
    opTemp = opStack[opStackIndex - 1] *= opStack[opStackIndex--];

    //"<-"
    lastBindDataIndex = opStack[opStackIndex - 1];
    data[lastBindDataIndex] = opTemp = opStack[opStackIndex], opStackIndex = 0;

    //null statement (non-context)

    //"4"
    opStack[++opStackIndex] = opTemp = 0x00000004;

    //"_VAL"
    opStack[++opStackIndex] = opTemp = data[0x00000004];

    //"1"
    opStack[++opStackIndex] = opTemp = 0x00000001;

    //"-"
    opTemp = opStack[opStackIndex - 1] -= opStack[opStackIndex--];

    //"<-"
    lastBindDataIndex = opStack[opStackIndex - 1];
    data[lastBindDataIndex] = opTemp = opStack[opStackIndex], opStackIndex = 0;

    //null statement (non-context)

    //";" (after "for")
    goto LABEL__AFTER_TO_00007FF6605854E8;
    LABEL__EXIT_FOR_00007FF660583BF8:
    --contextStackIndex;

    //ident "_END"(as label) previous ":"
    LABEL__0000024B1459FA48:

    //"_RES"
    opStack[++opStackIndex] = opTemp = data[0x00000008];

    //"put"
    (void)printf("%d\r\n", opTemp = opStack[opStackIndex]), opStackIndex = 0;

    //null statement (non-context)

    return 0;
}