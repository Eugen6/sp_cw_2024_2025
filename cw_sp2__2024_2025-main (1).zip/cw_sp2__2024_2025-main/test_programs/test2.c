#define _CRT_SECURE_NO_WARNINGS

#include "stdio.h"

int data[8192] = {0};
int contextStack[8192] = {0}, contextStackIndex = 0;
int opStack[8192] = {0}, opStackIndex = 0, opTemp = 0;
int lastBindDataIndex = 0;

int main() {
    contextStackIndex = 0;
    opStackIndex = 0;
    opTemp = 0;
    lastBindDataIndex = 0;

    //";"

    //"4"
    opStack[++opStackIndex] = opTemp = 0x00000004;

    //"get"
    (void)scanf_s("%d", &opTemp);
    data[opStack[opStackIndex]] = opTemp, opStackIndex = 0;

    //null statement (non-context)

    //"4"
    opStack[++opStackIndex] = opTemp = 0x00000004;

    //"_VAL"
    opStack[++opStackIndex] = opTemp = data[0x00000004];

    //"1"
    opStack[++opStackIndex] = opTemp = 0x00000001;

    //"+"
    opTemp = opStack[opStackIndex - 1] += opStack[opStackIndex--];

    //"<-"
    lastBindDataIndex = opStack[opStackIndex - 1];
    data[lastBindDataIndex] = opTemp = opStack[opStackIndex], opStackIndex = 0;

    //null statement (non-context)

    //"for"

    //"16"
    opStack[++opStackIndex] = opTemp = 0x00000010;

    //"0"
    opStack[++opStackIndex] = opTemp = 0x00000000;

    //"<-"
    lastBindDataIndex = opStack[opStackIndex - 1];
    data[lastBindDataIndex] = opTemp = opStack[opStackIndex], opStackIndex = 0;

    //null statement (non-context)

    //"to" (after "for")
    --data[lastBindDataIndex];
    contextStack[++contextStackIndex] = lastBindDataIndex;
    LABEL__AFTER_TO_00007FF721D87628:

    //"32767"
    opStack[++opStackIndex] = opTemp = 0x00007FFF;

    //null statement (non-context)

    //"do" (after "to" after "for")
    if (opStack[contextStack[contextStackIndex]] >= opTemp) goto LABEL__EXIT_FOR_00007FF721D85D38;
    ++opStack[contextStack[contextStackIndex]];

    //"8"
    opStack[++opStackIndex] = opTemp = 0x00000008;

    //"_VAL"
    opStack[++opStackIndex] = opTemp = data[0x00000004];

    //"1"
    opStack[++opStackIndex] = opTemp = 0x00000001;

    //"-"
    opTemp = opStack[opStackIndex - 1] -= opStack[opStackIndex--];

    //"<-"
    lastBindDataIndex = opStack[opStackIndex - 1];
    data[lastBindDataIndex] = opTemp = opStack[opStackIndex], opStackIndex = 0;

    //null statement (non-context)

    //"for"

    //"20"
    opStack[++opStackIndex] = opTemp = 0x00000014;

    //"0"
    opStack[++opStackIndex] = opTemp = 0x00000000;

    //"<-"
    lastBindDataIndex = opStack[opStackIndex - 1];
    data[lastBindDataIndex] = opTemp = opStack[opStackIndex], opStackIndex = 0;

    //null statement (non-context)

    //"to" (after "for")
    --data[lastBindDataIndex];
    contextStack[++contextStackIndex] = lastBindDataIndex;
    LABEL__AFTER_TO_00007FF721D8C0F8:

    //"32767"
    opStack[++opStackIndex] = opTemp = 0x00007FFF;

    //null statement (non-context)

    //"do" (after "to" after "for")
    if (opStack[contextStack[contextStackIndex]] >= opTemp) goto LABEL__EXIT_FOR_00007FF721D8A808;
    ++opStack[contextStack[contextStackIndex]];

    //"if"

    //"_DEV"
    opStack[++opStackIndex] = opTemp = data[0x00000008];

    //"2"
    opStack[++opStackIndex] = opTemp = 0x00000002;

    //"gr"
    opTemp = opStack[opStackIndex - 1] = opStack[opStackIndex - 1] >= opStack[opStackIndex--];

    //after cond expresion (after "if")
    if (opTemp == 0) goto LABEL__AFTER_THEN_00007FF721D8E660;

    //";" (after "then"-part of if-operator)
    opTemp = 1;
    LABEL__AFTER_THEN_00007FF721D8E660:

    //"else"
    if (opTemp != 0) goto LABEL__AFTER_ELSE_00007FF721D8F2D8;

    //"goto" previous ident "_ENB"(as label)
    goto LABEL__00000266583AAED8;

    //null statement (non-context)

    //";" (after "else")
    LABEL__AFTER_ELSE_00007FF721D8F2D8:

    //"12"
    opStack[++opStackIndex] = opTemp = 0x0000000C;

    //"_VAL"
    opStack[++opStackIndex] = opTemp = data[0x00000004];

    //"<-"
    lastBindDataIndex = opStack[opStackIndex - 1];
    data[lastBindDataIndex] = opTemp = opStack[opStackIndex], opStackIndex = 0;

    //null statement (non-context)

    //"for"

    //"24"
    opStack[++opStackIndex] = opTemp = 0x00000018;

    //"0"
    opStack[++opStackIndex] = opTemp = 0x00000000;

    //"<-"
    lastBindDataIndex = opStack[opStackIndex - 1];
    data[lastBindDataIndex] = opTemp = opStack[opStackIndex], opStackIndex = 0;

    //null statement (non-context)

    //"to" (after "for")
    --data[lastBindDataIndex];
    contextStack[++contextStackIndex] = lastBindDataIndex;
    LABEL__AFTER_TO_00007FF721D93980:

    //"32767"
    opStack[++opStackIndex] = opTemp = 0x00007FFF;

    //null statement (non-context)

    //"do" (after "to" after "for")
    if (opStack[contextStack[contextStackIndex]] >= opTemp) goto LABEL__EXIT_FOR_00007FF721D92090;
    ++opStack[contextStack[contextStackIndex]];

    //"if"

    //"_REM"
    opStack[++opStackIndex] = opTemp = data[0x0000000C];

    //"_DEV"
    opStack[++opStackIndex] = opTemp = data[0x00000008];

    //"gr"
    opTemp = opStack[opStackIndex - 1] = opStack[opStackIndex - 1] >= opStack[opStackIndex--];

    //after cond expresion (after "if")
    if (opTemp == 0) goto LABEL__AFTER_THEN_00007FF721D95EE8;

    //";" (after "then"-part of if-operator)
    opTemp = 1;
    LABEL__AFTER_THEN_00007FF721D95EE8:

    //"else"
    if (opTemp != 0) goto LABEL__AFTER_ELSE_00007FF721D96B60;

    //"goto" previous ident "_ENC"(as label)
    goto LABEL__00000266583A6CE8;

    //null statement (non-context)

    //";" (after "else")
    LABEL__AFTER_ELSE_00007FF721D96B60:

    //"12"
    opStack[++opStackIndex] = opTemp = 0x0000000C;

    //"_REM"
    opStack[++opStackIndex] = opTemp = data[0x0000000C];

    //"_DEV"
    opStack[++opStackIndex] = opTemp = data[0x00000008];

    //"-"
    opTemp = opStack[opStackIndex - 1] -= opStack[opStackIndex--];

    //"<-"
    lastBindDataIndex = opStack[opStackIndex - 1];
    data[lastBindDataIndex] = opTemp = opStack[opStackIndex], opStackIndex = 0;

    //null statement (non-context)

    //";" (after "for")
    goto LABEL__AFTER_TO_00007FF721D93980;
    LABEL__EXIT_FOR_00007FF721D92090:
    --contextStackIndex;

    //ident "_ENC"(as label) previous ":"
    LABEL__00000266583A6CE8:

    //"if"

    //"_REM"
    opStack[++opStackIndex] = opTemp = data[0x0000000C];

    //"0"
    opStack[++opStackIndex] = opTemp = 0x00000000;

    //"eq"
    opTemp = opStack[opStackIndex - 1] = opStack[opStackIndex - 1] == opStack[opStackIndex--];

    //after cond expresion (after "if")
    if (opTemp == 0) goto LABEL__AFTER_THEN_00007FF721D9C6D0;

    //"goto" previous ident "_ENB"(as label)
    goto LABEL__00000266583AAED8;

    //null statement (non-context)

    //";" (after "then"-part of if-operator)
    opTemp = 1;
    LABEL__AFTER_THEN_00007FF721D9C6D0:

    //"8"
    opStack[++opStackIndex] = opTemp = 0x00000008;

    //"_DEV"
    opStack[++opStackIndex] = opTemp = data[0x00000008];

    //"1"
    opStack[++opStackIndex] = opTemp = 0x00000001;

    //"-"
    opTemp = opStack[opStackIndex - 1] -= opStack[opStackIndex--];

    //"<-"
    lastBindDataIndex = opStack[opStackIndex - 1];
    data[lastBindDataIndex] = opTemp = opStack[opStackIndex], opStackIndex = 0;

    //null statement (non-context)

    //";" (after "for")
    goto LABEL__AFTER_TO_00007FF721D8C0F8;
    LABEL__EXIT_FOR_00007FF721D8A808:
    --contextStackIndex;

    //ident "_ENB"(as label) previous ":"
    LABEL__00000266583AAED8:

    //"if"

    //"_DEV"
    opStack[++opStackIndex] = opTemp = data[0x00000008];

    //"1"
    opStack[++opStackIndex] = opTemp = 0x00000001;

    //"eq"
    opTemp = opStack[opStackIndex - 1] = opStack[opStackIndex - 1] == opStack[opStackIndex--];

    //after cond expresion (after "if")
    if (opTemp == 0) goto LABEL__AFTER_THEN_00007FF721DA2668;

    //"goto" previous ident "_ENA"(as label)
    goto LABEL__00000266583A3948;

    //null statement (non-context)

    //";" (after "then"-part of if-operator)
    opTemp = 1;
    LABEL__AFTER_THEN_00007FF721DA2668:

    //"4"
    opStack[++opStackIndex] = opTemp = 0x00000004;

    //"_VAL"
    opStack[++opStackIndex] = opTemp = data[0x00000004];

    //"1"
    opStack[++opStackIndex] = opTemp = 0x00000001;

    //"+"
    opTemp = opStack[opStackIndex - 1] += opStack[opStackIndex--];

    //"<-"
    lastBindDataIndex = opStack[opStackIndex - 1];
    data[lastBindDataIndex] = opTemp = opStack[opStackIndex], opStackIndex = 0;

    //null statement (non-context)

    //";" (after "for")
    goto LABEL__AFTER_TO_00007FF721D87628;
    LABEL__EXIT_FOR_00007FF721D85D38:
    --contextStackIndex;

    //ident "_ENA"(as label) previous ":"
    LABEL__00000266583A3948:

    //"_VAL"
    opStack[++opStackIndex] = opTemp = data[0x00000004];

    //"put"
    (void)printf("%d\r\n", opTemp = opStack[opStackIndex]), opStackIndex = 0;

    //null statement (non-context)

    return 0;
}